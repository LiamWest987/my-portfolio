
  # Engineering Portfolio Website

  This is a code bundle for Engineering Portfolio Website. The original project is available at https://www.figma.com/design/Zx2ysI9sFw77VF0eGorkVQ/Engineering-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  