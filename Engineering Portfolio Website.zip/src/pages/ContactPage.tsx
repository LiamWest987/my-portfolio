import { Contact } from "../components/Contact";

export function ContactPage() {
  return (
    <div className="min-h-screen py-20">
      <Contact />
    </div>
  );
}
